"""
python-social-auth application, allows OpenId or OAuth user
registration/authentication just adding a few configurations.
"""
version = (0, 2, 19)
extra = ''
__version__ = '.'.join(map(str, version)) + extra
