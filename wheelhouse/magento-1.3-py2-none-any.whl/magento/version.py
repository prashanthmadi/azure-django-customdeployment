# -*- coding: utf-8 -*-
"""
    version

    Just the version here to avoid cyclic dependency when
    installing the module

    :copyright: © 2013 by Openlabs Technologies & Consulting (P) Limited
    :license: BSD, see LICENSE for more details.
"""
VERSION = '1.3'
