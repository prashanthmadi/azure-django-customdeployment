from social.apps.django_app.tests import *
