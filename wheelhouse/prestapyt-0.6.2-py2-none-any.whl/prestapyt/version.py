__author__ = "Guewen Baconnier <guewen.baconnier@gmail.com>"
__version__ = "0.6.2"
